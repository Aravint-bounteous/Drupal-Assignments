<?php

echo "Hello, world!\n";

$name=readline('enter the value of Name:');

 

if (strlen($name) < 2) {

  echo "Name should should be of more than 2 character\n";

}else{

  echo "Name-".$name;

}

 

$roll=readline('enter the value of Roll:');

$pattern = '/^[a-zA-Z]{3}(199\d|20\d{2})(?:1\d|2\d|3\d|4\d|5\d|6\d|70)$/';

 

 

if (preg_match($pattern, $roll)) {

  echo "Roll is valid.".$roll;

} else {

  echo "Invalid roll format. Please enter a valid roll.\n";

}

 

$semester=readline('enter the value of Semester:');

if ($semester>=1 && $semester<=8) {

  echo "Semester-".$semester;

}else{

  echo "semester should should be in between 1 to 8.\n";

}

$marks1=readline('enter the value of marks 1:');

if ($marks1>=1 && $marks1<=100) {

  echo "marks1-".$marks1;

}else{

  echo "marks1 should should be in between 1 to 100.\n";

}

$marks2=readline('enter the value of marks 1:');

if ($marks2>=1 && $marks2<=100) {

  echo "marks2-".$marks2;

}else{

  echo "marks2 should should be in between 1 to 100.\n";

}

$total=readline('enter the value of total :');

if ($total>=1 && $total<=200) {

  echo "total-".$total;

}else{

  echo "total should should be in between 1 to 200.\n";

}

$percentage=readline('enter the value of percentage :');

if ($percentage>=1 && $percentage<=100) {

  echo "percentage-".$percentage;

}else{

  echo "percentage should should be in between 1 to 100.\n";

}

$grade=readline('enter the value of grade :');

if (preg_match('/^[A-Fa-f]$/', $grade)) {

  echo "Grade is:".$grade;

} else {

  echo "Please enetr correct grade from A to F.\n";

}

 

echo "$name \n,$roll\n,$sem\n,$marks1\n,$marks2\n,$percentage\n,$total\n,$grade\n,$roll\n";